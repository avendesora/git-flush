import typer
from click import BadParameter

from git import InvalidGitRepositoryError, Repo

app = typer.Typer()


@app.command()
def main():
    try:
        repo = Repo("../..")
        print(repo.git.status())
    except InvalidGitRepositoryError as e:
        raise BadParameter("Not a git repository") from e


if __name__ == "__main__":
    app()
